object Ceasar {

  def main(args: Array[String]): Unit = {

    val alphToInts = Map(("a", 1), ("b", 2), ("c", 3), ("d", 4), ("e", 5), ("f", 6), ("g", 7), ("h", 8), ("i", 9),
      ("j", 10), ("k", 11), ("l", 12), ("m", 13), ("n", 14), ("o", 15), ("p", 16), ("q", 17), ("r", 18), ("s", 19),
      ("t", 20), ("u", 21), ("v", 22), ("w", 23), ("x", 24), ("y", 25), ("z", 26))

    val intToAlph = Map((1, "a"), (2, "b"), (3, "c"), (4, "d"), (5, "e"), (6, "f"), (7, "g"), (8, "h"), (9, "i"), (10, "j"),
      (11, "k"), (12, "l"), (13, "m"), (14, "n"), (15, "o"), (16, "p"), (17, "q"), (18, "r"), (19, "s"), (20, "t"),
      (21, "u"), (22, "v"), (23, "w"), (24, "x"), (25, "y"), (26, "z"))

    println("What would you like to do?")
    println("1-Encrypt  2-Decrypt  3-Find Possible Solutions")
    println("Please type in your choice. ")
    val choice = Console.readInt
    if (choice == 1) {
      println("Let's Go Encrypt!");
      println("By how many numbers would you like to shift?");
      val enshift = Console.readInt
      println("What word would you like to encrypt?");
      val usrword = Console.readLine

      val wordsToFind = usrword.split("");

      val increaseOne = wordsToFind.filter(x => alphToInts.contains(x)).map(x => if (alphToInts(x) + enshift <= 26) alphToInts(x) + enshift else (alphToInts(x) - 26 + enshift));
      val returnString = increaseOne.filter(x => intToAlph.contains(x)).map(x => intToAlph(x))

      println(returnString.mkString)

    } else if (choice == 2) {
      println("Let's Go Decrypt!");
      println("By how many numbers would you like to decrypt by?");
      val denshift = Console.readInt
      println("What word would you like to decrypt?");
      val usrWordDecr = Console.readLine

      val wordsToSolve = usrWordDecr.split("");

      val decreaseOne = wordsToSolve.filter(x => alphToInts.contains(x)).map(x => if (alphToInts(x) - denshift > 0) alphToInts(x) - denshift else (alphToInts(x) + 26 - denshift));
      val returnDecrString = decreaseOne.filter(x => intToAlph.contains(x)).map(x => intToAlph(x))

      println(returnDecrString.mkString)

    } else if (choice == 3) {
      println("Possible Solutions: ");

      println("We will shift by 1 for every cipher");

      println("What word would you like to dencrypt?");
      val usrWordChoic = Console.readLine

      val wordsToSolve = usrWordChoic.split("");

      for (i <- 0 to 26) {

        val increaseAll = wordsToSolve.filter(x => alphToInts.contains(x)).map(x => if (alphToInts(x) + i <= 26) alphToInts(x) + i else (alphToInts(x) - 26 + i));
        val returnValues = increaseAll.filter(x => intToAlph.contains(x)).map(x => intToAlph(x))

        println("Ceasar Cipher " + i + ": " + returnValues.mkString)
      }

    } else {
      println("type a choice please");
    }
  }

}

